using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class ScoreAndSpawning : MonoBehaviour
{
    private float score = 0;
    public Text scoreText;
    public GameObject goal;
    public GameObject player;
    private float xAxis;
    private float zAxis;
    // Start is called before the first frame update
    void Start()
    {
        score = 0;
        scoreText.text = score.ToString();
    }

    // Update is called once per frame
    void Update()
    {
        if (collision.gameObject.goal == "player")
        {
            score++;
            scoreText.text = score.ToString();
            var location = new Vector3(Random.Range(-197.5,21.6), 3, Random.Range(-3.2, 47.8));
            Instantiate(goal, location, Quaternion.identity);
        }
    }
}
