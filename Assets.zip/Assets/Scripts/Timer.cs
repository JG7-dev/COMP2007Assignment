using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class Timer : MonoBehaviour
{
    private float timeStart = 240;
    private float timeRemaining;
    public Slider timerBar;
    // Start is called before the first frame update
    void Start()
    {
        timeRemaining = timeStart;
        timerBar.maxValue = timeStart;
        timerBar.value = timeStart;
    }

    // Update is called once per frame
    void Update()
    {
        if(timeRemaining > 0){
            timeRemaining -= Time.deltaTime;
            timerBar.value = timeRemaining;
        }
    }
}
