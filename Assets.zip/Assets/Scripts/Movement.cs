using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Movement : MonoBehaviour
{
    //required for movement
    public GameObject player;
    private Vector2 turning;
    private Vector3 playerMovement;

    // Start is called before the first frame update
    void Start()
    {
        Cursor.lockState = CursorLockMode.Locked;
    }

    // Update is called once per frame
    void Update()
    {
        //Turning
        turning.x += Input.GetAxis("Mouse X");
        turning.y += Input.GetAxis("Mouse Y");
        transform.localRotation = Quaternion.Euler(-turning.y, turning.x, 0);
        //Moevement
        playerMovement = new Vector3(Input.GetAxisRaw("Horizontal"), 0, Input.GetAxisRaw("Vertical"));
        player.transform.Translate(playerMovement * 20f * Time.deltaTime);
    
    }
}
